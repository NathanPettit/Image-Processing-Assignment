%-----------------------------Median filtering with 5x5 neightbourhood mask

%--(Median) Step 5: Creating variables for later use

pad = padarray(n,[2 2]);%add zero padding
[c,d] = size(n);  % get height/width of zero padded array for use later
medArr = zeros(size(pad)); %array of zeros to save average pixel values to
 
mask = zeros(5);    %create 5*5 mask

figure
imshow(medArr);
title('Step-5: Zero-padded array to save median values to');

%--(Median) Step 6: nested loops for neighbourhood median filtering
for x = 3: c-2      
    for y = 3: d-2 %start on 3 and end on -2 to avoid zero padding
       
            i = n(x,y); % selects current pixel from the greyscale image
        
            for row = -2:2 % -2:2 will get every pixel within 2 positions of i
                for col = -2:2 
                    
                     mask(row +3, col +3) = n(x + row,y + col); %save each neighbour value to mask (3,3) is middle value
                     
                end
            end
         s = sort(mask(:)); %sort matrix values into linear array
         med1 = length(s);  %find length of array
         med2 =(med1+1)/2;  %divide by 2 to find middle value
         med3 = (s(floor(med2))+s(ceil(med2)))/2;
        medVal = med3; %calculate median value from mask
        medArr(x,y) = medVal; %save each new median value to medVal array
        
    end
end

medFinal=uint8(medArr); %covert back to unit8 so array can be displayed as image

figure
imshow(medFinal);
title('Step-6: Array filled with median values');