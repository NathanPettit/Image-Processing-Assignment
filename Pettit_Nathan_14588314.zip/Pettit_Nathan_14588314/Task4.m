 % MATLAB script for Assessment Item-1
%% Task-4
clear; close all; clc;

Task3

%% Step-1: Show stars image & calculate centroids/boundaries
figure
imshow(stars);
title('Step-1: Show task 3 output with centroids plotted');

% Calculate centroids for each starfish
s = regionprops(stars,'centroid');
centroids = cat(1, s.Centroid);

% Plot centroids onto stars
hold on
plot(centroids(:,1),centroids(:,2), 'b*')
hold off

% Save centre co-ords of stars & co-ords of star perimiters
starsCentre=regionprops(stars,'Centroid');  %save star centre co-ords
starBoundaries=bwboundaries(stars);  %save co-ords of perimeter for each star

%% Step-2: Find number of objects in the eroded binary image 
%          from task3 & calculate centroids/boundaries

[labled, objectQuantity] = bwlabel(BWfilled, 4); %calculate number of objects in image
allCentres=regionprops(BWfilled,'Centroid');  %save centres co-ords of all objects 
boundaries=bwboundaries(BWfilled);  %save co-ords of perimeter for each objects

figure
imshow(BWfilled);
title('Step-2: Show centroids of every object');
centroidsAll = cat(1, allCentres.Centroid);

% Plot centroids onto all objects
hold on
plot(centroidsAll(:,1),centroidsAll(:,2), 'b*')
hold off

%% find stars within eroded binary image
for k=1 : length(starsCentre) %for every star
   c=starsCentre(k).Centroid; %assign centroid to c
   bounds=starBoundaries(k);  %assign perimeter co-ords to bounds
   x=bounds{1,1}(:,1);        %split boundary co-ords int x and y arrays
   y=bounds{1,1}(:,2);
   cent2boundStars=sqrt((y-c(1)).^2+(x-c(2)).^2); %calculate distance between centroid and edge of star
   
     for j=1: length(allCentres)
         z=allCentres(j).Centroid; %assign centroid to c
         bounds1= boundaries(j);  %assign perimeter co-ords to bounds
         x=bounds1{1,1}(:,1);        %split boundary co-ords int x and y arrays
         y=bounds1{1,1}(:,2);
         cent2boundAll=sqrt((y-z(1)).^2+(x-z(2)).^2); %calculate distance between centroid and edge of star
         
         shapes(:) = bounds(:);
         %- If an object matches boundaries of a star signature
         if length(cent2boundStars) == length(cent2boundAll) 
            
             t=1:1:length(cent2boundAll);
             figure;
             subplot(3,1,1);
             plot(t,cent2boundAll); %- plot the graph of the star signature
             title('Distances between boundary & centroid plotted (star shape signatures)');
             subplot(3,1,2);
             visboundaries(bounds1,'Color', [0 0 1]); %- show the shape of the object that matches the star
             title('Drawn star shape signatures');
             subplot(3,1,3);
             imshow(BWfilled); %highlight 
             hold on;
             visboundaries(bounds1, 'Color', [1 0 1]);
             title('Drawn star shape signatures');
                 
         end 
         
         %- If an objects distance from centre to boundary is greater than 350 
         if 350 < length(cent2boundAll) && k==1
             
             t=1:1:length(cent2boundAll);
             figure;
             subplot(2,1,1);
             plot(t,cent2boundAll); %- plot the graph of the nonstar object
             title('Distances between boundary and centroid in non-star'); 
             subplot(2,1,2);
             visboundaries(bounds1); %- show the shape of the nonstar object
             title('Finding a shape signature that is not a star');
             
         end
         
     end
     
     %Display stars in binary image
     figure;
     imshow(BWfilled);
      hold on
     visboundaries(shapes);
     title('Star detected!');
end

%% Step 3- Highlight stars within binary image

%% Something I could've done is used the graphs to look for objects with 5 relativeky even peaks 
%  and called anything that matches this description a star
%  numel, findpeaks

