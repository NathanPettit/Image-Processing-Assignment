% MATLAB script for Assessment Item-1
% Task-4
clear; close all; clc;

% Step-1: Load input image
I = imread('Output images/stars.jpg');
figure;
imshow(I);
title('Step-1: Load input image');

% Step-2: Convert image to binary (as using Jpeg output from task 3)
BW = imbinarize(I, 0.9);
figure;
imshow(BW);
title('Step-2: Converted to binary');

% Step-3: Calculate centroids for each starfish
s = regionprops(BW,'centroid');
centroids = cat(1, s.Centroid);

figure
imshow(BW)
title('Step-3: Calculate centroids for each starfish');
hold on
plot(centroids(:,1),centroids(:,2), 'b*')
hold off

findpeaks(centroids(1,1));


% Step 5: Find the boundaries Concentrate only on the exterior boundaries.
% Option 'noholes' will accelerate the processing by preventing
% bwboundaries from searching for inner contours. 

%--[B,L] = bwboundaries(BW, 'noholes');

% Step 6: Determine objects properties
%---STATS = regionprops(L, 'all'); % we need 'BoundingBox' and 'Extent'
% Step 7: Classify Shapes according to properties
% Square = 3 = (1 + 2) = (X=Y + Extent = 1)
% Rectangular = 2 = (0 + 2) = (only Extent = 1)
% Circle = 1 = (1 + 0) = (X=Y , Extent < 1)
% UNKNOWN = 0
% 
% figure,
% imshow(I),
% title('Results');
% hold on
% for i = 1 : length(STATS)
%   W(i) = uint8(abs(STATS(i).BoundingBox(3)-STATS(i).BoundingBox(4)) < 0.1);
%   W(i) = W(i) + 2 * uint8((STATS(i).Extent - 1) == 0 );
%   centroid = STATS(i).Centroid;
%   switch W(i)
%       case 1
%           plot(centroid(1),centroid(2),'wO');
%       case 2
%           plot(centroid(1),centroid(2),'wX');
%       case 3
%           plot(centroid(1),centroid(2),'wS');
%   end
% end
% return

%---- count peaks(distance between centroid 