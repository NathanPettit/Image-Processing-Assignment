% MATLAB script for Assessment Item-1
% Task-2
clear; close all; clc;

%-Step 1: Load original image
N = imread('Sample Images/Noisy.png');

figure
imshow(N);
title('Step-1: Load input image');

%-Step 2: Convert image to greyscale
n = rgb2gray(N);

figure
imshow(n);
title('Step-2: Conversion of image to greyscale');

n = 255*im2double(n); %convert pixel values to doubles for manipulation

Task2mean

Task2median

%--Step 8: Display all 3 images

figure;

subplot(3,1,1) % Create a 3x1 matrix to diplay images
imshow(meanArr) % Display mean image on the top row
title('Mean Filtered Image')   

subplot(3,1,2)   
imshow(N)         % Display original image on the middle row
title('Noisy input Image')

subplot(3,1,3)
imshow(medFinal)% Display median filtered image on the bottom row
title('Median Filtered Image');

%---Display each alongside original image

figure;   % Display mean filtering alongside original image
axis on;
imshowpair(N,meanArr,'montage');
title('Mean Smoothing');

figure;   % Display median filtering alongside original image
axis on;
imshowpair(N,medFinal,'montage');
title('Median Smoothing');

%Step 8: Save output images
imwrite(meanArr,'Output Images/task2mean.png')
imwrite(medFinal,'Output Images/task2median.png')


