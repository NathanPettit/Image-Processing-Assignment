%--------------     BILINEAR INTERPOLATION      --------------%

%   get new image dimensions and create zero array to fill later
blArray = zeros(nHeight,nWidth);
hs = (height/nHeight);
ws = (width/nWidth);

% Step-4: Bilinear Interpolation
for i = 1:nHeight %                 For each pixel in resized array
    y = (hs * i) + (0.5 * (1 - 1/factor));
    for j = 1:nWidth
        x = (ws * j) + (0.5 * (1 - 1/factor));
        
        %   don't use values oustside of max height/width
        x(x < 1) = 1;
        x(x > height - 0.001) = height - 0.001;
        x1 = floor(x);
        x2 = x1 +1; 
        if x2 > width
            x2 = x2 - 1;
        end
        if x1 > width
            x1 = x1 - 1;
        end
        
        y(y < 1) = 1;
        y(y > width - 0.001) = width - 0.001;
        y1 = floor(y);
        y2 = y1 + 1; 
        if y1 > height
            y1 = y1 - 1;
        end
        if y2 > height
            y2 = y2 - 1;
        end
        
        %   Four nearest pixel values
        NP1 = Igray(y1,x1); %(1,1)
        NP2 = Igray(y1,x2); %(1,2)
        NP3 = Igray(y2,x1); %(2,1)
        NP4 = Igray(y2,x2); %(2,2)
        
        %   Pixel weighting
        A = (y2-y)*(x2-x);
        B = (y2-y)*(x-x1);
        C = (y-y1)*(x2-x);
        D = (y-y1)*(x-x1);
        
        %   Calculating distance weighted average for new image pixels
        blArray(i,j) = (A*NP1 + B*NP2 + C*NP3 + D*NP4)/255;
    end
end

figure
imshow(blArray);
imwrite(blArray,'Output Images/task1bl.jpg')  %save bilinear scaled image
title('Step-4: Bilinear image scaling');