
%-Mean Filtering

%-(Mean)Step 3: Create new array with zero padding for later use 
pixels = padarray(n,[2 2]);     %add zero padding
meanArr = zeros(size(pixels)); %array of zeros to save average pixel values to
[a,b] = size(meanArr); % get height/width of zero padded array for use later

figure
imshow(meanArr);
title('Step-3: Zero-padded array of zeros to save mean values to');

%-(Mean)Step 4: nested loops for neighbourhood mean smoothing
for x = 3: a-2         
    for y = 3: b-2  % start on 3 and end on b-2 to avoid the zero padding  
        sum = 0;
        for row = x-2:x+2 %5*5 array includes all pixels with 2 pixels either side of x
            for col = y-2:y+2
                % calculate and save mean values to sum
                sum = sum + (1/25)*pixels(row,col);  
            end
        end
        meanArr(x,y) = sum/255; %fill new array with mean values
    end
end

figure
imshow(meanArr);
title('Step-4: Zero-padded array filled with mean filtered values');