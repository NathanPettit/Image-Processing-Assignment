% MATLAB script for Assessment Item-1
% Task-3
clear; close all; clc;

%% Step-1: Load input image
I = imread('Sample Images/Starfish.jpg');
figure;
imshow(I);
title('Step-1: Load input image');

%% Step-2: Convert to greyscale and apply median blending
G = rgb2gray(I);
M = medfilt2(G);
figure;
imshow(M);
title('Step-2: Convert image to greyscale and apply median blending');

%% Step-3: Contrast stretch and convert to binary 

M=decorrstretch(M, 'Tol', 0.05); %
BW = imbinarize(M, 0.7);
figure;
imshow(BW);
title('Step-3: Increase contrast & convert to binary');

%% Step-4: Invert image
WB = ~(BW); %imcomplement(BW)
figure;
imshow(WB);
title('Step-4: Invert image');

%% Step-5: Fill holes in objects
BWfill = imfill(WB, 'holes');
figure;
imshow(BWfill);
title('Step-5: Remove Holes in objects');

%% Step-6: Erode image
sDisk = strel('disk', 2);
BWfilled = imopen(BWfill, sDisk);
figure;
imshow(BWfilled);
title('Step-6: Erosion');

%% Step-7: Filter out objects based on area and eccentricty 
% ratio of major axis to minor axis
filter = bwpropfilt(BWfilled, 'eccentricity', [0.56 0.73]); %filter out based on how circular objects are (circles have a value of 0, lines 1)
stars = bwpropfilt(filter,'area', [1200 1700]); %filtering out objects that aren't between this area range (that aren't stars)

figure;
imshow(stars);
title('Step-7: Filter out objects with a small perimeter');


