% MATLAB script for Assessment Item-1
% Task-3
clear; close all; clc;

% Step-1: Load input image
I = imread('Sample Images/Starfish.jpg');
figure;
imshow(I);
title('Step-1: Load input image');

% Step-2: Convert to greyscale
G = rgb2gray(I);
figure;
imshow(G);
title('Step-2: Convert image to greyscale');

% Step-3: Median filtering to remove noise
M = medfilt2(G);
figure;
imshow(M);
title('Step-3: Median filtered to remove noise');

% Step-4: Convert image to binary
BW = imbinarize(M, 0.9);
figure;
imshow(BW);
title('Step-4: Converted to binary');

% Step-5: Invert image
WB = ~(BW); %imcomplement(BW)
figure;
imshow(WB);
title('Step-5: Invert image');

%Step-6: Filter out small objects to leave the 7 largest objects
figure
BW2 = bwpropfilt(WB,'perimeter',7);
imshow(BW2);
title('Step-6: Filter out objects with a small perimeter');

% Step-7: Filter out objects with large areas
figure
BW3 = bwareafilt(BW2,2);
imshow(BW3);
title('Step-7: Filter out objects with large areas');

% Step-8: Remove objects with large areas from image
stars = BW2 - BW3;
figure
imwrite(stars,'Output Images/stars.jpg')
imshow(stars);
title('Step-8: Remove large objects to leave a binary image showing only starfish');



% texture, colour, 
%find shape sizes

%bwarea(WB)

% BW2 = regionprops(WB, 'Centroid',...
%     'MajorAxisLength','MinorAxisLength');

%bwpropfilt

%remove small shapes

%remove large perimiter objects (find permiter of stars)


