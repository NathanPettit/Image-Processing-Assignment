%--Nearest Neighbour Interpolation

nnArray = uint8(zeros(nHeight, nWidth));

% Step-3: Nearest Neighbour Interpolation
for i= 0:nHeight-1
  for j= 0:nWidth-1
    x = floor(j/factor);
    y = floor(i/factor);
      nnArray(i+1, j+1) = Igray(y+1, x+1);
  end
end

figure;
imwrite(nnArray,'Output Images/task1nn.jpg')  %save nearest neighbour scaled image
imshow(nnArray) %show nearest neighbour scaled image
title('Step-3: Nearest Neighbour scaling');
