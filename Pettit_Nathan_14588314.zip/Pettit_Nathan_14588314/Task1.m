% MATLAB script for Assessment Item-1
% Task-1
clear; close all; clc;

% Step-1: Load input image
I = imread('Sample Images/Zebra.jpg');
figure;
imshow(I);
title('Step-1: Load input image');

% Step-2: Conversion of input image to grey-scale image
Igray = rgb2gray(I);
figure;
imshow(Igray);
title('Step-2: Conversion of input image to greyscale');

Igray = 255*im2double(Igray); %convert pixel values to doubles for manipulation

%   get new image dimensions and create zero array to fill later
factor = 3;  % 3* scale factor 
[height, width] = size(Igray);   %find resolution of current image
nWidth = (width*factor);
nHeight = (height*factor);

Task1nn
Task1bl


            





    

    


